import os,time,subprocess,pathlib,json
s=time.monotonic()
while os.path.exists('/proc/19329'):
 if time.monotonic()-s>1500:raise TimeoutError('chat suite wait')
 time.sleep(2)
with open('pcie-measured.txt','w') as f:
 for i in range(3):
  f.write('trial '+str(i)+'\n');f.flush();subprocess.run(['/tmp/artemis-tools/pcie-probe'],stdout=f,stderr=subprocess.STDOUT,timeout=30,check=True)
subprocess.run(['python','memory_probes.py'],stdout=open('memory-probes.out','w'),stderr=subprocess.STDOUT,timeout=1100)
bin=str(next(pathlib.Path('/tmp/artemis-tools/official').rglob('llama-bench')))
cmd=[bin,'-m','/tmp/artemis-tools/model.gguf','-ngl','99','-sm','layer,tensor','-ts','1/1','-fa','on','-ctk','f16','-ctv','f16','-b','512','-ub','128','-t','4','-p','512','-n','64','-d','0,4096','-r','3','-o','json']
json.dump(cmd,open('official-bench-command.json','w'),indent=2)
try:
 r=subprocess.run(cmd,stdout=open('official-bench-results.json','w'),stderr=open('official-bench-run.log','w'),timeout=900)
 print('bench return',r.returncode,flush=True)
except subprocess.TimeoutExpired:print('bench timed out',flush=True)
