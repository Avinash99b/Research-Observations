from run_server_tests import run
import json
prompt=json.load(open('natural-prompt-template.json'))['prompt']
configs=[('natural_layer_f16',[]),('natural_tensor_f16',['-sm','tensor']),('natural_tensor_q8',['-sm','tensor','-ctk','q8_0','-ctv','q8_0']),('natural_tensor_q4',['-sm','tensor','-ctk','q4_0','-ctv','q4_0']),('natural_layer_q4',['-ctk','q4_0','-ctv','q4_0']),('natural_draft_layer',['--model-draft','/tmp/artemis-tools/draft.gguf','--spec-type','draft-simple','--spec-draft-ngl','all','--spec-draft-n-max','3'])]
for name,args in configs:run(name,args+['--ctx-checkpoints','0','--cache-ram','0','-lv','4'],n=96,prompt_text=prompt,request_timeout=120)
