## Verification and scope

This is a bounded search for the best observed configuration, not a proof of a universal optimum. Literal model names, versions, commits, quant names and flags are identifiers. Numeric arguments in commands inherit the classification immediately above the command. Original machine logs are retained without inserting tags; the evidence README classifies those as [MEASURED].

| Environment item | Result |
|---|---|
| Hardware | Tesla T4, count 2 [MEASURED] |
| Raw VRAM per GPU | 15,360 MiB [MEASURED] |
| Driver reservation per GPU | 449 MiB [MEASURED] |
| CUDA-visible capacity per GPU | 14,911 MiB [MEASURED] |
| Initial CUDA context per GPU | about 105 MiB [MEASURED] |
| Driver / reported CUDA compatibility | `580.178.04` / `13.0` [MEASURED] (identifiers) |
| Installed CUDA compiler toolkit | `12.8.93` [MEASURED] (identifier) |
| Available CPU threads | 4 [MEASURED] |
| System RAM | 32,869,452 KiB [MEASURED] |
| Working filesystem capacity | 20,957,446,144 bytes [MEASURED] |
| Working filesystem free before model download | 20,930,285,568 bytes [MEASURED] |
| Temporary filesystem free before download | 1,145,490,419,712 bytes [MEASURED] |
| Interconnect | PHB, no NVLink path reported [MEASURED] |
| PCIe link, each GPU | generation 3, width 16 [MEASURED] |
| CUDA peer access | unsupported in topology query; direct-access test false [MEASURED] |

The GGUF would leave only **22,632,000 bytes [CALCULATED]** on the working disk before further logs. Large downloads were placed in the checked temporary filesystem. The working directory holds the evidence and convenience symlinks. GPU clocks were not locked. Temperature reached **79 degrees C [MEASURED]**, with substantial clock variation [MEASURED], so small differences in the chronological sweep are not conclusive.

The executable runs, has no missing `ldd` dependencies, contains `sm_75` cubins, and completed GPU inference [MEASURED]. It reports `0.6.0-dev`, build `0`, commit `unknown` [MEASURED] (identifiers). Its exact source and claim to be the latest build cannot be verified. SHA-256: `3d73017477cb64c9b8a9a32ae097d0a11b4ab48cab05932d5520d56edfbe8bc7` [MEASURED] (identifier).

| Capability | Runtime verification |
|---|---|
| Flash attention | enabled; on/off comparison completed [MEASURED] |
| f16, q8_0 and q4_0 symmetric KV | accepted and generated output [MEASURED] |
| Layer split | works [MEASURED] |
| Row split | flag exists, but fails: `device CUDA0 does not support split buffers` [MEASURED] |
| Tensor split | works in tested non-draft cases; experimental [MEASURED] |
| Draft model | layer-split draft decoding works [MEASURED] |
| Tensor split plus tested draft | aborts in meta-backend split-state assertion [MEASURED] |
| Mapping controls | this build uses `--load-mode`; `none` was tested [MEASURED] |

The target file has **20,907,653,568 bytes [MEASURED]** and its SHA-256 matches the repository LFS hash: `55da3ba2a0c7326110aa11234bf8a127a7f24d5fb58fc653da792cff011de920` [MEASURED] (identifier). Its tensor directory has **833 tensors [MEASURED]**, **30,697,345,596 parameters [MEASURED]**, and **20,891,818,224 tensor bytes [MEASURED]**. Q4_K_L is a mixed tensor quantization, not uniform four-bit weights.

| GGUF metadata | Value |
|---|---|
| Architecture | `gemma4` [MEASURED] |
| Layers / embedding width | 60 / 5,376 [MEASURED] |
| Query heads | 32 [MEASURED] |
| Local attention | 50 layers; KV heads 16; K/V head dimension 256; window 1,024 tokens [MEASURED] |
| Global attention | 10 layers; KV heads 4; K/V head dimension 512 [MEASURED] |
| Attention pattern | five local layers followed by one global layer, repeated [MEASURED] |
| Trained context | 262,144 tokens [MEASURED] |
| Shared KV layers | 0 [MEASURED] |
| Feed-forward width | 21,504 [MEASURED] |
| BOS | ID 2, required by metadata [MEASURED] |

Head dimensions must come from metadata. Dividing embedding width by query-head count gives the wrong cache sizes.

## Memory calculations and their limits

The ordinary layer-split load allocates **9,908.34 MiB and 10,015.73 MiB of GPU model buffers [MEASURED]**, plus **1,102.50 MiB CPU-mapped embedding [MEASURED]**. Tensor split allocates **10,515.87 MiB per GPU [MEASURED]**. Its model-layout overhead needs a separate budget. CPU-mapped bytes are not VRAM.

Let C be single-slot context, u physical microbatch, and sK/sV stored bytes per scalar. The following formulas are [CALCULATED] from the measured layout. Storage formats use **2 bytes/scalar for f16 [MEASURED] (format)**, **34/32 for q8_0 [MEASURED] (format)**, and **18/32 for q4_0 [MEASURED] (format)**, including quantization scales.

```text
S(C,u) = round_up(min(C, 1024 + u), 256)
KV(C,u) = 10*C*4*512*(sK+sV) + 50*S(C,u)*16*256*(sK+sV)
VRAM_i = weights_i + KV_i(C,u) + scratch_i(C,u,b,FA,split,KV_type) + runtime_i
```

[CALCULATED] (formulas) These apply without `--swa-full`, to a single slot. Padding and compact-window allocation were checked against logs. Each GPU must fit independently.

| Symmetric KV | Global bytes per context token | Local bytes per window cell | KV at trained limit with microbatch 128 [MEASURED] (setting) |
|---|---:|---:|---:|
| f16 | 81,920 [CALCULATED] | 819,200 [CALCULATED] | 20.98 GiB [CALCULATED] |
| q8_0 | 43,520 [CALCULATED] | 435,200 [CALCULATED] | 11.14 GiB [CALCULATED] |
| q4_0 | 23,040 [CALCULATED] | 230,400 [CALCULATED] | 5.90 GiB [CALCULATED] |

Microbatches **128, 256 and 512 [MEASURED] (settings)** allocate **1,280, 1,280 and 1,536 local cells [MEASURED]** respectively. Full-size SWA would make even q4 KV alone **61.875 GiB at the trained limit [CALCULATED]**, before weights. It cannot fit entirely in these GPUs.

Before benchmarking, a preliminary aggregate budget assumed **512 MiB runtime/scratch headroom [ESTIMATED]**, after measured driver reservation. It predicted ceilings of **107,264 f16 tokens [CALCULATED]**, **213,248 q8 tokens [CALCULATED]**, and **414,208 q4 tokens [CALCULATED]**, capped by the trained limit. These were predictions, not usable-context results. Large-context quantized scratch invalidated that headroom assumption.

### Scratch as a function of microbatch and context

| Layer/f16, context 4,096 [MEASURED] (setting) | GPU A compute MiB | GPU B compute MiB | Host compute MiB |
|---|---:|---:|---:|
| microbatch 128 [MEASURED] | 80.15 [MEASURED] | 56.52 [MEASURED] | 31.53 [MEASURED] |
| microbatch 256 [MEASURED] | 160.30 [MEASURED] | 113.04 [MEASURED] | 63.05 [MEASURED] |
| microbatch 512 [MEASURED] | 321.59 [MEASURED] | 227.07 [MEASURED] | 127.11 [MEASURED] |

At that context, total GPU scratch is approximately **1.068 MiB per physical-batch token [CALCULATED] (fit)**. At physical microbatch **128 [MEASURED]**, increasing context from **4,096 to 98,304 [MEASURED] (settings)** adds **92 MiB per GPU [MEASURED]** in the pipeline graph, matching **8*u*(C-4096) bytes [CALCULATED] (fit)** per GPU.

Quantized KV has an additional context-dependent workspace. At physical microbatch **128 [MEASURED] (setting)**, first-GPU pipeline requests are **97.77 MiB at context 4,096 [MEASURED]**, **1,789.77 MiB at context 196,608 [MEASURED] (attempted allocation)**, and **2,365.77 MiB at context 262,144 [MEASURED] (attempted allocation)**. Small-context q4 and q8 compute reservations are identical [MEASURED]. These points fit:

```text
pipeline scratch_A(C,u=128) = (8192 + 8*u)*C + 61.77 MiB
serial fallback scratch_A(C,u=128) = (8192 + 2*u)*C + 28.10 MiB
```

[CALCULATED] (empirical fits) The larger serial-fallback requests were **1,612.10 MiB and 2,140.10 MiB [MEASURED]**. The large context slope is consistent with full-cache conversion/work buffers [ESTIMATED] (interpretation); no profiler trace or verified source commit proves the exact internal cause. Extending these fits to other microbatches or split modes is [ESTIMATED].

At fixed physical microbatch **128 [MEASURED]**, changing logical batch **512 to 2,048 [MEASURED] (settings)** left shallow tensor-split compute reservation at **43.32 MiB per Meta instance [MEASURED]**. Logical and physical batches are different. Scratch is peak live graph allocation; graph fallback, attention mode, context, cache type and split matter. It cannot be modeled accurately as a fixed percentage of weights.

### Revised per-device pipeline budget

Using the measured layer weights, cache distribution and fitted scratch slopes, with **128 MiB per-device runtime headroom [ESTIMATED]**, gives the following [CALCULATED] budgets at physical microbatch **128 [MEASURED] (setting)**. These are build/graph-specific estimates, not hard allocator boundaries. Serial fallback can fit a larger context, and deeper graph allocations can consume the margin.

| KV | Revised pipeline context budget |
|---|---:|
| f16 | 105,728 tokens [CALCULATED] |
| q8_0 | 151,296 tokens [CALCULATED] |
| q4_0 | 232,192 tokens [CALCULATED] |

### Bandwidth bounds

Nominal T4 bandwidth is **320 GB/s per GPU [ESTIMATED] (input supplied by the task)**, not measured sustained kernel bandwidth. These are optimistic [CALCULATED] single-request, non-speculative, unbatched decode bounds:

```text
R_KV(C) = global_bytes_per_token*C + local_bytes_per_cell*min(C, window)
layer_step_time >= sum_i((W_i + R_KV_i(C))/BW_i)
tensor_step_time >= max_i((W_i + R_KV_i(C))/BW_i) + communication_time
row_step_time >= max_i(W_i/BW_i) + R_KV(C)/BW_main + communication_time
communication_time >= bytes_moved / link_bandwidth + synchronization_latency
```

[CALCULATED] (formulas) Ignoring KV and overhead, sequential layer splitting is bounded by **15.32 tokens/s [CALCULATED]** and ideal parallel weight reads by **30.63 tokens/s [CALCULATED]**. Minimum KV traffic assumes ideal GQA reuse; repeated reads, conversions, replicated weights, compute and synchronization reduce actual speed. Row split is unavailable in this executable [MEASURED]. Row KV would reside on the main device rather than enjoy the same sharded capacity as tensor mode.

The ideal minimum-read ceilings at selected depths are [CALCULATED], using the same nominal-bandwidth assumption. They are not achievable-throughput predictions:

| KV / depth | Minimum bytes read per target token | Layer ceiling | Ideal tensor ceiling |
|---|---:|---:|---:|
| f16 / 0 tokens [CALCULATED] (scenario) | 20,891,818,224 bytes [CALCULATED] | 15.32 tok/s [CALCULATED] | 30.63 tok/s [CALCULATED] |
| f16 / 32,768 tokens [CALCULATED] (scenario) | 24,415,033,584 bytes [CALCULATED] | 13.11 tok/s [CALCULATED] | 26.21 tok/s [CALCULATED] |
| q4_0 / 262,144 tokens [CALCULATED] (scenario) | 27,167,545,584.0 bytes [CALCULATED] | 11.78 tok/s [CALCULATED] | 23.56 tok/s [CALCULATED] |

PCIe link payload has a theoretical per-direction limit of **15.75 GB/s [CALCULATED]**. Median pinned-memory host-to-device bandwidth was **10.99 / 10.59 GB/s [MEASURED]**, device-to-host **12.12 / 11.02 GB/s [MEASURED]**, and serial host-staged GPU-to-GPU effective bandwidth **5.66 GB/s [MEASURED]**. This is a transfer probe, not NCCL collective profiling. There is no measured NVLink or peer-access path.

Speculation and concurrent-request batches amortize weight reads across tokens, so their aggregate throughput is not constrained by the single unbatched target-step bound in the same way.
