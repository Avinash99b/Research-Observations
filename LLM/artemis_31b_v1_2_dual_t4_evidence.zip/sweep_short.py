from run_server_tests import run
import json,time
configs=[
('layer_f16',['-lv','4']),
('layer_q8',['-ctk','q8_0','-ctv','q8_0','-lv','4']),
('layer_q4',['-ctk','q4_0','-ctv','q4_0','-lv','4']),
('row_f16',['-sm','row','-lv','4']),
('tensor_f16',['-sm','tensor','-lv','4']),
('layer_f16_no_fa',['-fa','off','-lv','4']),
('layer_f16_ub256',['-ub','256','-lv','4']),
('layer_f16_ub512',['-ub','512','-lv','4']),
('layer_f16_t2',['-t','2','-lv','4']),
('layer_f16_split_4_5',['-ts','4,5','-lv','4']),
('row_f16_mg1',['-sm','row','-mg','1','-lv','4']),
('layer_f16_nommap',['--load-mode','none','-lv','4']),
]
t=time.monotonic()
for name,args in configs:
 if time.monotonic()-t>1500:print('suite time budget reached',flush=True);break
 run(name,args,request_timeout=120,load_timeout=150)
