from run_server_tests import run
configs=[('alloc_layer_f16_98304',['-c','98304']),('alloc_layer_f16_106496',['-c','106496']),('oom_layer_f16_114688',['-c','114688']),('alloc_layer_q8_196608',['-c','196608','-ctk','q8_0','-ctv','q8_0']),('oom_layer_q8_262144',['-c','262144','-ctk','q8_0','-ctv','q8_0']),('alloc_layer_q4_262144',['-c','262144','-ctk','q4_0','-ctv','q4_0']),('alloc_tensor_q4_262144',['-sm','tensor','-c','262144','-ctk','q4_0','-ctv','q4_0'])]
for name,args in configs:run(name,args+['--ctx-checkpoints','0','--cache-ram','0','-lv','4'],reps=0,load_timeout=180)
