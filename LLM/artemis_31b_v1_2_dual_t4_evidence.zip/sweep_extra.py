from run_server_tests import run
import time
configs=[
('tensor_f16_ub256',['-sm','tensor','-ub','256']),
('tensor_f16_ub512',['-sm','tensor','-ub','512']),
('tensor_q8',['-sm','tensor','-ctk','q8_0','-ctv','q8_0']),
('tensor_q4',['-sm','tensor','-ctk','q4_0','-ctv','q4_0']),
('tensor_b2048',['-sm','tensor','-b','2048']),
('tensor_nocache',['-sm','tensor','--ctx-checkpoints','0','--cache-ram','0']),
('draft_layer',['--model-draft','/tmp/artemis-tools/draft.gguf','--spec-type','draft-simple','--spec-draft-ngl','all','--spec-draft-n-max','3','--ctx-checkpoints','0','--cache-ram','0']),
]
for name,args in configs:run(name,args+['-lv','4'],load_timeout=150,request_timeout=180)
run('tensor_p2p',['-sm','tensor','-lv','4'],env={'GGML_CUDA_P2P':'1'},load_timeout=90,request_timeout=90)
