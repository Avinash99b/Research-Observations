import run_server_tests as h
import json, time, pathlib, hashlib, urllib.request, urllib.parse

TOTAL_CTX = 262144
GEN_TOKENS = 64
REPS = 3
first_depth = TOTAL_CTX - REPS * GEN_TOKENS  # 261952

def send_notify(msg, summary=""):
    payload = json.dumps({"description": msg[:200], "summary": summary[:800]})
    url = "https://trigger.macrodroid.com/2a3f03e4-c9a3-462c-8ac1-d713a586db99/notify-the-great-avinash?" + urllib.parse.urlencode({"description": payload})
    try:
        r = urllib.request.urlopen(url, timeout=20)
        out = f"HTTP {r.status}"
    except Exception as e:
        out = f"ERROR {e}"
    print("Notify:", out, flush=True)
    with open("notify.log", "a") as f:
        f.write(f"{msg[:80]!r} -> {out}\n")

real = h.requests.post
history = None
details = []

class Result:
    def __init__(self, d): self.d = d
    def raise_for_status(self): pass
    def json(self): return self.d

def post(url, **kwargs):
    global history
    if not url.endswith('/completion'):
        return real(url, **kwargs)
    body = dict(kwargs['json'])
    body['return_tokens'] = True
    body['cache_prompt'] = (history is not None)
    if history is not None:
        body['prompt'] = history
    actual = len(body['prompt'])
    t = time.monotonic()
    req_timeout = 3000 if not details else 300
    print(f"Sending request: start_depth {actual}, cache_prompt={body['cache_prompt']}, timeout={req_timeout}s...", flush=True)
    r = real(url, json=body, timeout=req_timeout)
    r.raise_for_status()
    d = r.json()
    ids = d.get('tokens')
    assert isinstance(ids, list) and len(ids) == GEN_TOKENS, f"missing generated token ids: {ids}"
    history = body['prompt'] + ids
    d['timings']['actual_start_depth'] = actual
    detail = {
        'start_depth': actual,
        'end_depth': len(history),
        'timings': d['timings'],
        'truncated': d.get('truncated', False),
        'wall_seconds': time.monotonic() - t,
        'generated_tokens': ids,
        'content': d.get('content', '')[:1000]
    }
    details.append(detail)
    json.dump(details, open('full-depth-details.json', 'w'), indent=2)
    step_idx = len(details)
    pp_s = d['timings'].get('prompt_per_second', 0)
    tg_s = d['timings'].get('predicted_per_second', 0)
    print(f"Full depth sample {step_idx}/{REPS}: {actual} -> {len(history)} tokens (cache_n={d['timings'].get('cache_n')}, PP={pp_s:.2f} tps, TG={tg_s:.2f} tps, elapsed={time.monotonic()-t:.1f}s)", flush=True)
    send_notify(
        f"Full-depth sample {step_idx}/{REPS} complete: {actual} -> {len(history)} tokens",
        f"Start: {actual}, End: {len(history)}, PP: {pp_s:.2f} TPS [MEASURED], TG: {tg_s:.2f} TPS [MEASURED], Wall: {time.monotonic()-t:.1f}s [MEASURED]"
    )
    return Result(d)

common = ['--ctx-checkpoints', '0', '--cache-ram', '0', '--no-context-shift']
extra = [
    '-sm', 'tensor', '-ts', '1,1',
    '-c', '262144',
    '-ctk', 'q4_0', '-ctv', 'q4_0',
    '-b', '2048', '-ub', '128',
    '--override-tensor', 'token_embd.weight=CPU'
] + common

h.requests.post = post
try:
    send_notify(
        "Starting full-depth validation run (261,952 -> 262,144 tokens)",
        "Tensor split + CPU embedding, c=262144, q4 KV, ub128. Cold prefill of 261,952 tokens starting."
    )
    record = h.run('full_depth_validated', extra, [first_depth], n=GEN_TOKENS, reps=REPS, request_timeout=3000, load_timeout=300)
    print("full_depth_validated run finished with result:", record.get('error'))
finally:
    h.requests.post = real

