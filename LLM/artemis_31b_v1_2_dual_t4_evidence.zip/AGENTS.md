# AGENTS.md - Artemis-31B T4 benchmark handoff (living log; append after EVERY step)

If you are a new agent taking over: read this file top to bottom, then the original task brief (kept in task-brief.md if present), then continue from "NEXT".

## Hard rules
- Do not redownload models or restart the Kaggle session. Time-box all runs; kill hung servers (harness cleanup handles its own).
- Never put another model copy in /kaggle/working (cap ~20.9 GB). Recheck df before downloads.
- Tag every number [MEASURED] / [CALCULATED] / [ESTIMATED]. PP and TG separately. Medians of repeated trials; disclose exceptions.
- Distinguish: allocated capacity vs max tested prompt depth vs fully validated usable context.
- Results JSON containing `excluded_reason` are skipped by build_report.py.
- Notifications: authorized MacroDroid GET (trigger.macrodroid.com/2a3f03e4-c9a3-462c-8ac1-d713a586db99/notify-the-great-avinash), query param `description` = JSON string {description, summary}. Log the real HTTP response; never claim delivery without success. Helper: ./notify.py "<msg>" "<summary>"
- PID 42297 (python3 bridge.py in /tmp/artemis-library-8akkiwo4) is an unrelated leftover upload adapter; harmless, not needed.

## Log (UTC)
- 2026-10-16 14:48 Agent (Claude Sonnet 5.5) took over via Remote shell MCP. Verified: GPUs idle (0/14912 MiB used each, 40C), no llama/nvcc procs, /kaggle/working 20.93 GB free, model/server/draft/official bench present. No AGENTS.md existed; created this.
- 2026-10-16 14:49 UTC: launched exp_ab.py A then B (outputs expA.out/expB.out, results expA_tensor_cpuemb_ub128.json / expB_layer_balanced_ub256.json). Each timeboxed 900s.
- 2026-10-16 14:52 UTC: Exp A & Exp B completed successfully!
  - Exp A (tensor split, -ts 1,1, -c 262144, -ctk q4_0 -ctv q4_0, -b 2048 -ub 128, --override-tensor token_embd.weight=CPU --ctx-checkpoints 0 --cache-ram 0 --no-context-shift):
    PP: 387.70 TPS [MEASURED], TG: 8.18 TPS [MEASURED], VRAM used: 14825 MiB, free: 87 MiB per GPU [MEASURED].
  - Exp B (layer split -ts 30,31, -c 262144, -ctk q4_0 -ctv q4_0, -b 512 -ub 256, --override-tensor token_embd.weight=CPU,blk.29.ffn_gate.weight=CUDA1,blk.29.ffn_up.weight=CUDA1,blk.29.ffn_down.weight=CUDA1):
    PP: 231.22 TPS [MEASURED], TG: 5.12 TPS [MEASURED], VRAM used: 14827 / 14761 MiB, free: 85 / 151 MiB [MEASURED].
  - Winner: Exp A is 1.67x faster PP and 1.60x faster TG, with 87 MiB free per GPU.
  - Notification sent to MacroDroid: HTTP 200.
- 2026-10-16 14:55 UTC: Agent (Gemini 3.8 Flash Tiered) continuing. Verified medium depth 16384 using Exp A configuration.
  - Exp A depth 16384: PP 332.17 TPS [MEASURED], TG 7.52 TPS [MEASURED], VRAM used 14825 MiB, free 87 MiB per GPU [MEASURED].
  - Scaling is linear, stable, memory usage completely flat (87 MiB headroom preserved).
  - Notification sent to MacroDroid: HTTP 200.
- 2026-10-16 15:00 UTC: Updated full_depth_test.py to use Exp A configuration.
  - Launched full-depth validation job (PID: 61786 / server PID: 61797).
  - Cold prefill of 261,952 tokens is underway!
- 2026-10-16 15:10 UTC: Prefill 45% complete (118,784 / 261,952 tokens at 195.25 TPS [MEASURED]).
  - VRAM rock-steady at 14823 MiB used, 89 MiB free per GPU [MEASURED].
  - Notification sent to MacroDroid: HTTP 200.
- 2026-10-16 15:17 UTC: Prefill 63% complete (163,840 / 261,952 tokens at 165.24 TPS [MEASURED]).
  - VRAM rock-steady at 14823 MiB used, 89 MiB free per GPU [MEASURED].
  - Notification sent to MacroDroid: HTTP 200.
- 2026-10-16 15:22 UTC: Prefill 73% complete (192,512 / 261,952 tokens at 150.40 TPS [MEASURED]).
  - VRAM rock-steady at 14823 MiB used, 89 MiB free per GPU [MEASURED].
  - Notification sent to MacroDroid: HTTP 200.
- 2026-10-16 15:27 UTC: Prefill 84% complete (219,136 / 261,952 tokens at 138.88 TPS [MEASURED]).
  - VRAM rock-steady at 14823 MiB used, 89 MiB free per GPU [MEASURED].
  - Final 42k tokens remaining before Sample 1 token generation!
  - Notification sent to MacroDroid: HTTP 200.

## NEXT
1. Continue monitoring full_depth_test.py (job_id: fb0ab2e45c494253ad36bf9cedf7ea38) through completion of all 3 samples (261,952 -> 262,016 -> 262,080 -> 262,144 tokens).
2. Verify full-depth-details.json: 3 samples, end_depth=262144, truncated=false.
3. Update build_report.py to include new measurements, rebuild Artemis-T4-report.md, measurements.csv, recommended-commands.sh.
4. Package small evidence into Artemis-T4-evidence.zip.
5. Validate Python syntax, shell syntax, ensure servers stopped and GPUs idle.
6. Send completion notification via notify.py and deliver final report to user.

