import json,re,glob,os
meta=json.load(open('metadata-full.json'));W=sum(t['bytes'] for t in json.load(open('tensors.json')))
out={}
for q,s in [('f16',2),('q8_0',34/32),('q4_0',18/32)]:
 out[q]=[]
 for c in [0,4096,16384,32768,98304,196608,262144]:
  kv_read=81920*(s/2)*c+819200*(s/2)*min(c,1024)
  out[q].append({'context':c,'kv_read_bytes':kv_read,'ideal_layer_tps':320e9/(W+kv_read),'ideal_tensor_tps':640e9/(W+kv_read)})
json.dump(out,open('bandwidth-calculations.json','w'),indent=2)
for name in ['layer_f16','layer_f16_ub256','layer_f16_ub512','layer_f16_no_fa','tensor_f16','tensor_b2048']:
 p=name+'.log'
 if not os.path.exists(p):continue
 print(name)
 for line in open(p):
  if 'compute buffer size' in line or ('KV cache' in line and 'size =' in line):print(line.strip())
