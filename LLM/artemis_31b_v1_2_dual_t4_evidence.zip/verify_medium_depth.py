
import run_server_tests as h, json, sys

common = ['--ctx-checkpoints','0','--cache-ram','0','--no-context-shift']
extra = ['-sm','tensor','-ts','1,1','-c','262144','-ctk','q4_0','-ctv','q4_0','-b','2048','-ub','128','--override-tensor','token_embd.weight=CPU'] + common

print("Starting medium-depth test (16384) with Exp A...", flush=True)
res = h.run('expA_tensor_depth_16384', extra, depths=[16384], n=64, reps=2, request_timeout=300, load_timeout=300)
print("Finished medium-depth test!", flush=True)

