import os,sys,json,time,subprocess,requests,signal,statistics,pathlib,threading
import resource
resource.setrlimit(resource.RLIMIT_CORE,(0,0))
ROOT=pathlib.Path('/kaggle/working/artemis-bench');os.chdir(ROOT)
BIN=str(ROOT/'llama-server-sm75'); MODEL='/tmp/artemis-tools/model.gguf';URL='http://127.0.0.1:18080'
def gpu():
 try:return subprocess.check_output(['nvidia-smi','--query-gpu=memory.used,memory.free,utilization.gpu,power.draw,clocks.sm,clocks.mem','--format=csv,noheader,nounits'],text=True).strip()
 except:return ''
def run(name,extra,depths=[512],n=64,reps=3,env=None,request_timeout=240,load_timeout=150,prompt_text=None):
 cmd=[BIN,'-m',MODEL,'-ngl','all','--fit','off','-sm','layer','-ts','1,1','-mg','0','-fa','on','-ctk','f16','-ctv','f16','-c','4096','-b','512','-ub','128','-t','4','-np','1','--host','127.0.0.1','--port','18080','--no-webui','--no-warmup']+extra
 record={'name':name,'command':cmd,'env':env or {},'trials':[],'started':time.time()};log=open(ROOT/(name+'.log'),'w');p=None
 try:
  p=subprocess.Popen(cmd,stdout=log,stderr=subprocess.STDOUT,start_new_session=True,env=dict(os.environ,**(env or {})))
  record['pid']=p.pid;json.dump({'pid':p.pid,'name':name},open(ROOT/'active-server.json','w'));ready=False;t=time.monotonic()
  while time.monotonic()-t<load_timeout:
   if p.poll() is not None:raise RuntimeError('server exited '+str(p.returncode))
   try:
    r=requests.get(URL+'/health',timeout=2)
    if r.status_code==200:ready=True;break
   except requests.RequestException:pass
   time.sleep(1)
  if not ready:raise TimeoutError('load timeout')
  record['gpu_loaded']=gpu()
  tok=requests.post(URL+'/tokenize',json={'add_special':prompt_text is not None,'parse_special':True,'content':prompt_text if prompt_text is not None else 'The traveler walked through the village and observed the market. ' * 3000},timeout=20).json()['tokens']
  # Token-array prompts preserve exact depths. Repeated corpus is a speed probe, not a quality benchmark.
  for depth in depths:
   prompt=tok if prompt_text is not None else (([2]+(tok*((depth//len(tok))+1)))[:depth] if depth>1 else [2])
   depth=len(prompt)
   for rep in range(reps):
    body={'prompt':prompt,'n_predict':n,'temperature':0,'seed':42,'ignore_eos':True,'cache_prompt':False,'stream':False}
    t=time.monotonic();r=requests.post(URL+'/completion',json=body,timeout=request_timeout);r.raise_for_status();d=r.json()
    trial={'depth':depth,'rep':rep,'timings':d.get('timings'),'wall_seconds':time.monotonic()-t,'tokens_evaluated':d.get('tokens_evaluated'),'tokens_predicted':d.get('tokens_predicted'),'truncated':d.get('truncated'),'stop_type':d.get('stop_type'),'content_sample':d.get('content','')[:2048],'gpu':gpu()}
    record['trials'].append(trial);print(name,json.dumps(trial),flush=True)
 except Exception as e:record['error']=repr(e);print(name,'ERROR',repr(e),flush=True)
 finally:
  if p is not None and p.poll() is None:
   os.killpg(p.pid,signal.SIGTERM)
   try:p.wait(timeout=8)
   except subprocess.TimeoutExpired:os.killpg(p.pid,signal.SIGKILL);p.wait()
  log.close();
  active=ROOT/'active-server.json'
  if active.exists():active.unlink()
  record['ended']=time.time();json.dump(record,open(ROOT/(name+'.json'),'w'),indent=2)
 return record
if __name__=='__main__':
 name=sys.argv[1];extra=json.loads(sys.argv[2]);depths=json.loads(sys.argv[3]) if len(sys.argv)>3 else [512]
 run(name,extra,depths)
