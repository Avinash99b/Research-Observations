import run_server_tests as h, json, sys
which = sys.argv[1]
common = ['--ctx-checkpoints','0','--cache-ram','0','--no-context-shift']
if which == 'A':
    # tensor split, CPU token_embd, q4 KV, full ctx
    h.run('expA_tensor_cpuemb_ub128',
          ['-sm','tensor','-ts','1,1','-c','262144','-ctk','q4_0','-ctv','q4_0','-b','2048','-ub','128',
           '--override-tensor','token_embd.weight=CPU']+common,
          [4096], n=64, reps=3, request_timeout=240, load_timeout=300)
elif which == 'B':
    # existing layer placement with ub256
    h.run('expB_layer_balanced_ub256',
          ['-sm','layer','-ts','30,31','-c','262144','-ctk','q4_0','-ctv','q4_0','-b','512','-ub','256',
           '--override-tensor','token_embd.weight=CPU,blk.29.ffn_gate.weight=CUDA1,blk.29.ffn_up.weight=CUDA1,blk.29.ffn_down.weight=CUDA1']+common,
          [4096], n=64, reps=3, request_timeout=240, load_timeout=300)
