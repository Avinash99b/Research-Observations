from run_server_tests import run
import json
base=['-c','262144','-ctk','q4_0','-ctv','q4_0','-ts','30,31','--override-tensor','token_embd.weight=CPU','-b','512','--ctx-checkpoints','0','--cache-ram','0','--no-context-shift','-lv','4']
run('balanced_tensor_q8_131072',['-sm','tensor','-c','131072','-ctk','q8_0','-ctv','q8_0','-ub','128','-b','2048','--ctx-checkpoints','0','--cache-ram','0','--no-context-shift','-lv','4'],[4096],request_timeout=180,load_timeout=180)
a=run('full_cpu_output_ub64',base+['-ub','64'],[4096],request_timeout=180,load_timeout=180)
b=run('full_cpu_output_ub128',base+['-ub','128'],[4096],request_timeout=180,load_timeout=180)
if a.get('error') and b.get('error'):
 run('full_cpu_output_ffn_ub64',base+['--override-tensor','token_embd.weight=CPU,blk.0.ffn_down.weight=CPU','-ub','64'],[4096],request_timeout=180,load_timeout=180)

if not a.get('error') or not b.get('error'):
 run('full_cpu_output_balanced_ub128',base+['--override-tensor','token_embd.weight=CPU,blk.29.ffn_down.weight=CUDA1','-ub','128'],[4096],request_timeout=180,load_timeout=180)

