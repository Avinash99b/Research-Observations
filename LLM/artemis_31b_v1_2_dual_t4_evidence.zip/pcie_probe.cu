#include <cuda_runtime.h>
#include <cstdio>
#include <chrono>
#include <cstdlib>
#define CK(x) do{auto e=(x);if(e!=cudaSuccess){fprintf(stderr,"%s\n",cudaGetErrorString(e));return 1;}}while(0)
int main(){const size_t N=64*1024*1024;const int R=16;void*h;void*d[2];CK(cudaMallocHost(&h,N));for(int i=0;i<2;i++){CK(cudaSetDevice(i));CK(cudaMalloc(&d[i],N));CK(cudaMemset(d[i],0,N));}int p=0;CK(cudaDeviceCanAccessPeer(&p,0,1));printf("peer_access_0_to_1=%d bytes=%zu repetitions=%d\n",p,N,R);
for(int i=0;i<2;i++){CK(cudaSetDevice(i));for(int dir=0;dir<2;dir++){auto t=std::chrono::steady_clock::now();for(int r=0;r<R;r++){if(dir==0){CK(cudaMemcpy(d[i],h,N,cudaMemcpyHostToDevice));}else{CK(cudaMemcpy(h,d[i],N,cudaMemcpyDeviceToHost));}}double s=std::chrono::duration<double>(std::chrono::steady_clock::now()-t).count();printf("gpu=%d direction=%s GBps=%.6f\n",i,dir==0?"H2D":"D2H",N*double(R)/s/1e9);}}
auto t=std::chrono::steady_clock::now();for(int r=0;r<R;r++){CK(cudaSetDevice(0));CK(cudaMemcpy(h,d[0],N,cudaMemcpyDeviceToHost));CK(cudaSetDevice(1));CK(cudaMemcpy(d[1],h,N,cudaMemcpyHostToDevice));}double s=std::chrono::duration<double>(std::chrono::steady_clock::now()-t).count();printf("staged_0_to_1_effective_GBps=%.6f\n",N*double(R)/s/1e9);for(int i=0;i<2;i++){CK(cudaSetDevice(i));CK(cudaFree(d[i]));}CK(cudaFreeHost(h));}
