## Feasibility, tradeoffs and limitations

At the full trained limit, f16 weights plus KV exceed raw combined VRAM [CALCULATED]. Symmetric q8 weights plus compact KV also exceed it before runtime overhead [CALCULATED]. Those all-GPU configurations are impossible under this layout. Q4 weights plus KV fit, but the measured scratch requests make the original all-GPU configuration fail [MEASURED]. Split ratios cannot cure an aggregate deficit. CPU tensor placement or different build-specific scratch behavior changes the calculation.

The f16 allocation at **106,496 tokens [MEASURED]** succeeds only after pipeline allocation fails and the server falls back to serial scheduling [MEASURED]. Loaded-only probes establish allocation feasibility, not full-depth generation. The measurement tables distinguish configured capacity, processed prompt depth and maximum-context validation.

| Choice | Speed | Capacity / memory | Quality / practical consequence |
|---|---|---|---|
| f16 KV | strong baseline | largest persistent KV | reference KV precision; fixed GGUF weight quantization unchanged |
| q8 KV | fastest non-draft corrected short-chat control here | smaller KV, but scratch still grows | less aggressive KV quantization; accuracy loss not quantified |
| q4 KV | check depth measurements | smallest tested persistent KV | more aggressive lossy KV; long-range quality untested |
| Layer split | lower shallow rates than leading tensor cases | lower model-buffer footprint | sequential GPU work; supports tested draft model |
| Tensor split | higher shallow throughput | extra model-layout overhead | experimental; draft combination asserted |
| Larger physical microbatch | improves prefill when memory permits | more scratch, sometimes more SWA padding | no intended precision change; floating-point ordering can change greedy output |
| Disable SWA checkpoints and RAM prompt cache | avoids expensive host copies | less host-RAM pressure | gives up rollback/prefix-edit reuse; pure append can still reuse a slot |
| Draft model | strong gain on repetitive input, smaller chat gain | extra model and runtime memory | acceptance is workload dependent |
| More slots | more aggregate service throughput | more total KV or less context per slot | slower individual requests |
| CPU tensor placement | enables otherwise unavailable capacity | frees VRAM, uses CPU RAM | slows affected operations without changing weight quantization |

Known failures and untested work:

- Row mode failed with either tested main-GPU choice [MEASURED]. Tensor mode plus the tested draft aborted in a meta-backend assertion [MEASURED]. OOM and fallback logs remain in the evidence.
- `GGML_CUDA_FORCE_MMQ` is a compile-time option in inspected source. No effective runtime `GGML_CUDA_PEER_ACCESS` support was found. `GGML_CUDA_P2P` was actually tested and showed no reliable gain. Relevant baseline environment variables were unset [MEASURED].
- Equivalent no-mmap loading was tested. Memory locking was not swept: host swap was absent [MEASURED], and it cannot directly accelerate already resident GPU weights.
- CPU offload was explored only after the full trained-context all-GPU allocation failed. Exhaustive split ratios, mixed K/V precisions, all layer counts and draft sizes were not swept.
- Clocks and temperature varied [MEASURED]. The chronological sweep is not randomized; small differences do not establish causal gains. No confidence intervals or universal optimality claim are made.
- Quality checks only verify prompt formatting and readable opening reasoning. There was no perplexity, retrieval-accuracy, task-accuracy or long-chat quality benchmark.
- Preliminary `natural_*` controls omitted required BOS and are marked excluded. Corrected `chat_*` controls supersede them. Main speed prompts already included BOS.
- The maximum-depth procedure cold-prefills once, then measures real sequential continuations near the limit. It does not provide repeated cold full-context prefill measurements. This exception avoids spending the session repeating the most expensive prefill; it is not concealed as a cached-prompt median.
- Beyond-trained-context RoPE extrapolation was not tested. A memory fit does not prove useful distant-token recall.
- A matching `llama-bench` for the supplied unknown-commit executable was unavailable. The separate official benchmark build is identified below; its timings are not merged into server results.

## Sources and reproduction

Primary evidence is live shell/GPU output, GGUF metadata and tensor directory, server logs, per-request timing JSON and benchmark samples in the accompanying bundle.

- [Target GGUF repository](https://huggingface.co/bartowski/TheDrummer_Artemis-31B-v1.2-GGUF)
- [Supplied executable](https://files.avinash9.in/movies/llama-server-sm75)
- [Draft GGUF repository](https://huggingface.co/ggml-org/gemma-4-E2B-it-GGUF)
- [Official benchmark release](https://github.com/ggml-org/llama.cpp/releases/tag/b11696)
- [Inspected source snapshot](https://github.com/ggml-org/llama.cpp/tree/f3363593f457169cdfbdfe22ea399b1cc139ba18); this is not asserted to be the supplied executable's source.

The model and binary paths are session-local. Re-download after a Kaggle reset. The bundle includes exact commands, scripts, measurement CSV, metadata and raw evidence; it excludes GGUF weights, executables and source/build trees. Each experiment has a timeout and cleanup. Failed and excluded controls remain visible.
