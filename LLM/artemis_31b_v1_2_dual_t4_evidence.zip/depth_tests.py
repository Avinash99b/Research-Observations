from run_server_tests import run
import time,json,subprocess
subprocess.run(['python','rescue_allocations.py'],stdout=open('rescue-allocations.out','w'),stderr=subprocess.STDOUT,timeout=900)
common=['--ctx-checkpoints','0','--cache-ram','0','--no-context-shift','-b','2048','-ub','512','-lv','4']
configs=[('depth_tensor_f16',['-sm','tensor','-c','65536'],[1,4096,16384,32768]),('depth_tensor_q8',['-sm','tensor','-c','98304','-ctk','q8_0','-ctv','q8_0'],[4096,16384,32768]),('depth_tensor_q4',['-sm','tensor','-c','229376','-ctk','q4_0','-ctv','q4_0'],[4096,16384,32768]),('depth_layer_q4',['-c','229376','-ctk','q4_0','-ctv','q4_0'],[4096,32768])]
for i,(name,args,depths) in enumerate(configs):
 if name=='depth_tensor_q4' and json.load(open('alloc_tensor_q4_229376.json')).get('error'):
  args[args.index('-c')+1]='196608'
start=time.monotonic()
for name,args,depths in configs:
 if time.monotonic()-start>3600:print('deep suite time budget reached',flush=True);break
 run(name,args+common+(['-ub','128'] if ('q4' in name or 'q8' in name) else []),depths,request_timeout=420,load_timeout=180)
