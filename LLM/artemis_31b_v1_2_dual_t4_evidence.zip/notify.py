#!/usr/bin/env python3
import sys, json, urllib.request, urllib.parse
msg = sys.argv[1] if len(sys.argv) > 1 else "update"
summ = sys.argv[2] if len(sys.argv) > 2 else ""
payload = json.dumps({"description": msg[:200], "summary": summ[:800]})
url = "https://trigger.macrodroid.com/2a3f03e4-c9a3-462c-8ac1-d713a586db99/notify-the-great-avinash?" + urllib.parse.urlencode({"description": payload})
try:
    r = urllib.request.urlopen(url, timeout=20)
    out = f"HTTP {r.status}"
except Exception as e:
    out = f"ERROR {e}"
print(out)
open("notify.log", "a").write(f"{msg[:80]!r} -> {out}\n")
