import json,glob,statistics,os
for fn in glob.glob('*.json'):
 try:d=json.load(open(fn))
 except:continue
 if 'trials' not in d:continue
 out=[]
 for depth in sorted(set(t['depth'] for t in d['trials'])):
  a=[t for t in d['trials'] if t['depth']==depth and t.get('timings')]
  if a:out.append(dict(depth=depth,reps=len(a),pp=round(statistics.median(t['timings']['prompt_per_second'] for t in a),3),tg=round(statistics.median(t['timings']['predicted_per_second'] for t in a),3),gpu=a[-1]['gpu'].splitlines()))
 print(d['name'],json.dumps(out),d.get('error',''))
