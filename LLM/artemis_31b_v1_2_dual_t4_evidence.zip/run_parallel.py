import run_server_tests as h
import concurrent.futures,time,json,statistics
real=h.requests.post
class Result:
 def __init__(self,d):self.d=d
 def raise_for_status(self):pass
 def json(self):return self.d
for slots in [2,4]:
 samples=[]
 def post(url,**kwargs):
  if not url.endswith('/completion'):return real(url,**kwargs)
  def worker(i):
   body=dict(kwargs['json'],id_slot=i);t=time.monotonic();r=real(url,json=body,timeout=kwargs['timeout']);r.raise_for_status();return dict(response=r.json(),wall=time.monotonic()-t)
  t=time.monotonic()
  with concurrent.futures.ThreadPoolExecutor(max_workers=slots) as ex:out=list(ex.map(worker,range(slots)))
  wall=time.monotonic()-t;v={'slots':slots,'wall_seconds':wall,'aggregate_end_to_end_tps':sum(x['response']['tokens_predicted'] for x in out)/wall,'requests':out};samples.append(v)
  d=dict(out[0]['response']);d['timings']=dict(d['timings'],parallel=v);return Result(d)
 h.requests.post=post
 h.run('parallel_tensor_'+str(slots),['-sm','tensor','-np',str(slots),'-c',str(4096*slots),'--ctx-checkpoints','0','--cache-ram','0','-lv','4'],n=128,request_timeout=180)
 json.dump(samples,open('parallel-'+str(slots)+'-details.json','w'),indent=2)
h.requests.post=real
