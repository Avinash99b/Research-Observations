from run_server_tests import run
cases=[('alloc_layer_q4_229376',['-c','229376','-ctk','q4_0','-ctv','q4_0']),('alloc_tensor_q4_229376',['-sm','tensor','-c','229376','-ctk','q4_0','-ctv','q4_0']),('alloc_layer_q4_full_ngl60',['-c','262144','-ctk','q4_0','-ctv','q4_0','-ngl','60']),('alloc_layer_q4_full_ngl59',['-c','262144','-ctk','q4_0','-ctv','q4_0','-ngl','59']),('alloc_tensor_q8_98304',['-sm','tensor','-c','98304','-ctk','q8_0','-ctv','q8_0'])]
for name,args in cases:run(name,args+['--ctx-checkpoints','0','--cache-ram','0','-lv','4'],reps=0,load_timeout=150)
