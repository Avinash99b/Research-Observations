import os,json,glob,statistics,shlex,csv,pathlib
os.chdir('/kaggle/working/artemis-bench')
def read(p,default=None):
 try:return json.load(open(p))
 except (FileNotFoundError,json.JSONDecodeError):return default
def m(v):return (f'{v:,}' if isinstance(v,int) else f'{v:.2f}')+' [MEASURED]'
data={}
for p in glob.glob('*.json'):
 d=read(p)
 if isinstance(d,dict) and 'command' in d and 'trials' in d and not d.get('excluded_reason'):data[d['name']]=d
def opt(d,k,default='-'):
 v=default
 for i,a in enumerate(d['command'][:-1]):
  if a==k:v=d['command'][i+1]
 return v
def command(d):
 valued={'-m','-ngl','--fit','-sm','-ts','-mg','-fa','-ctk','-ctv','-c','-b','-ub','-t','-np','--host','--port','-lv','--ctx-checkpoints','--cache-ram','--load-mode','--override-tensor','--model-draft','--spec-type','--spec-draft-ngl','--spec-draft-n-max'}
 parts=[];idx={};a=d['command'];i=1
 while i<len(a):
  k=a[i];v=[k,a[i+1]] if k in valued else [k];i+=len(v)
  if k in idx:parts[idx[k]]=v
  else:idx[k]=len(parts);parts.append(v)
 return shlex.join([a[0]]+[x for p in parts for x in p])
rows=[]
for name,d in data.items():
 if d.get('excluded_reason') or name.startswith(('natural_','parallel_')):continue
 for dep in sorted(set(t['depth'] for t in d['trials'])):
  a=[t for t in d['trials'] if t['depth']==dep and t.get('timings')]
  if not a:continue
  mem=[]
  for i in range(2):
   try:mem.append(max(int(t['gpu'].splitlines()[i].split(',')[0]) for t in a))
   except (ValueError,KeyError,IndexError):mem.append(0)
  rows.append({'config':name,'split':opt(d,'-sm'),'KV':opt(d,'-ctk')+'/'+opt(d,'-ctv'),'context':int(opt(d,'-c')),'batch':int(opt(d,'-b')),'ubatch':int(opt(d,'-ub')),'threads':int(opt(d,'-t')),'ngl':opt(d,'-ngl'),'FA':opt(d,'-fa'),'depth':dep,'repeats':len(a),'GPU_A_MiB':mem[0],'GPU_B_MiB':mem[1],'pp_tps':statistics.median(t['timings']['prompt_per_second'] for t in a),'tg_tps':statistics.median(t['timings']['predicted_per_second'] for t in a),'classification':'MEASURED'})
with open('measurements.csv','w') as f:
 w=csv.DictWriter(f,fieldnames=list(rows[0]));w.writeheader();w.writerows(rows)
def table(names):
 s=['| Config | KV K/V | Context | Prompt depth | Batch / microbatch | Sampled VRAM MiB per GPU | pp tok/s | tg tok/s | Repeats | Notes |','|---|---|---:|---:|---|---|---:|---:|---:|---|']
 for n in names:
  rr=[r for r in rows if r['config']==n]
  for r in rr:
   notes=r['split']+', ngl='+r['ngl']+', threads='+str(r['threads'])+', FA='+r['FA']+' [MEASURED] (settings)'
   s.append('| '+ ' | '.join([n,r['KV'],m(r['context']),m(r['depth']),m(r['batch'])+' / '+m(r['ubatch']),m(r['GPU_A_MiB'])+' / '+m(r['GPU_B_MiB']),m(r['pp_tps']),m(r['tg_tps']),m(r['repeats']),notes])+' |')
  if not rr and n in data and data[n].get('error'):
   d=data[n];s.append('| '+' | '.join([n,opt(d,'-ctk')+'/'+opt(d,'-ctv'),m(int(opt(d,'-c'))),'-',m(int(opt(d,'-b')))+' / '+m(int(opt(d,'-ub'))),'-','failed [MEASURED]','failed [MEASURED]','-',d['error']])+' |')
 return chr(10).join(s)
full=read('full-depth-details.json',[]);ok=len(full)==3 and full[-1]['end_depth']==262144 and all(not x.get('truncated') for x in full)
balanced=data.get('depth_tensor_q8')
context=data.get('full_depth_validated') if ok else data.get('depth_layer_q4')
profiles={k:v for k,v in [('speed',data.get('draft_layer')),('context',context),('balanced',balanced)] if v}
s=['# Artemis: measured Kaggle dual-T4 performance and context report','## Recommendations']
if 'draft_layer' in data:
 a=data['draft_layer']['trials'];s.append('Fastest shallow repetitive-prompt result: **'+m(statistics.median(t['timings']['predicted_per_second'] for t in a))+' generation tokens/s** with layer-split draft decoding. This is workload dependent. Corrected chat controls and depth results are below.')
if ok:s.append('Full trained context validated through **'+m(262144)+' tokens**, without truncation [MEASURED]. Median generation near the limit: **'+m(statistics.median(x['timings']['predicted_per_second'] for x in full))+' tokens/s**. CPU placement is required as shown below.')
else:s.append('Full trained-context validation is not complete. Allocated capacity and actually processed depth are separate; do not infer full-depth usability from allocation alone.')
for k,d in profiles.items():
 s.append('### '+{'speed':'Maximum observed shallow speed','context':'Maximum context','balanced':'Balanced'}[k])
 s.append('[MEASURED] (configuration) Numeric arguments below are tested settings. Run only one profile at a time. The speed profile benefits most from repetitive text; see the corrected chat comparison.\n\n```bash\n'+command(d)+'\n```')
s.append(pathlib.Path('report-head.md').read_text())
s.append('## Supplied-server throughput measurements\n\nUnless stated otherwise, cells are medians of repeated requests. Greedy sampling and EOS suppression keep generation length fixed; all tokens, including reasoning, are counted. Server decode timing excludes the first prompt-produced token. Cold-prompt reuse is disabled. VRAM is the maximum sample after completed requests, not a continuously measured peak.')
s.append('### Short sweep\n'+table(['layer_f16','layer_q8','layer_q4','row_f16','tensor_f16','layer_f16_no_fa','layer_f16_ub256','layer_f16_ub512','layer_f16_t2','layer_f16_split_4_5','row_f16_mg1','layer_f16_nommap','tensor_f16_ub256','tensor_f16_ub512','tensor_q8','tensor_q4','tensor_b2048','tensor_nocache','tensor_p2p','draft_layer']))
s.append('### Corrected chat controls\n'+table(['chat_layer_f16','chat_tensor_f16','chat_tensor_q8','chat_tensor_q4','chat_layer_q4','chat_draft_layer','chat_draft_tensor']))
s.append('These use the model template and required BOS. Readable opening reasoning does not establish completion quality or long-context accuracy. The preliminary natural controls are excluded.')
s.append('### Depth tests\n'+table(['depth_tensor_f16','depth_tensor_q8','depth_tensor_q4','depth_layer_q4','balanced_tensor_q8_131072','expA_tensor_cpuemb_ub128','expA_tensor_depth_16384','expB_layer_balanced_ub256','full_cpu_output_ub64','full_cpu_output_ub128','full_cpu_output_ffn_ub64','full_cpu_output_balanced_ub128','full_cpu_output_ffn_gpu_balanced','full_depth_validated']))
s.append('Context shifting is disabled. A BOS-only prompt is not a bulk prompt benchmark. Configured context and processed prompt depth are separate columns. The deep profiles have different microbatches to fit their memory budgets, so cross-profile differences are not a pure one-variable KV comparison.')
s.append('### Full-depth validation')
if full:
 s.append('| Start depth | End depth | Cached tokens | New prompt tokens | pp tok/s | tg tok/s | Truncated |\n|---:|---:|---:|---:|---:|---:|---|')
 for x in full:
  t=x['timings'];s.append('| '+' | '.join([m(x['start_depth']),m(x['end_depth']),m(t.get('cache_n',0)),m(t['prompt_n']),m(t['prompt_per_second']),m(t['predicted_per_second']),str(x.get('truncated'))+' [MEASURED]'])+' |')
 s.append('Only the first request cold-prefills the long prefix. Later requests append real generated token IDs and reuse the growing history. The generation median covers consecutive near-limit continuations; cold full-prefix PP is measured once, not as a repeated median. The cold request limit is **3,000 seconds [MEASURED] (experiment setting)**.')
else:s.append('No completed full-prefix measurement is available.')
if data.get('full_depth_validated',{}).get('error'):s.append('Full-depth failure [MEASURED]: `'+data['full_depth_validated']['error']+'`.')
s.append('### Parallel slots\n| Slots | Median per-request tg tok/s | Median aggregate end-to-end tok/s |\n|---:|---:|---:|')
for p in sorted(glob.glob('parallel-*-details.json')):
 a=read(p,[])
 if a:s.append('| '+m(a[0]['slots'])+' | '+m(statistics.median(q['response']['timings']['predicted_per_second'] for x in a for q in x['requests']))+' | '+m(statistics.median(x['aggregate_end_to_end_tps'] for x in a))+' |')
s.append('Aggregate end-to-end includes prompt processing and request overhead. Each request generates **128 tokens [MEASURED] (setting)**, and each slot has **4,096 tokens of capacity [MEASURED] (setting)**. Aggregate end-to-end throughput is not isolated decode throughput.')
s.append('## Separate official llama-bench cross-check\n\nOfficial build `11696`, commit `ceefd16da`, version `0.7.0-dev` [MEASURED] (identifiers). Archive digest matches the release asset [MEASURED]: `8efa76e0d3c667ea3593e91a05068187c486113779f32a43fc1553496129c872`. A source build was stopped to avoid contention after its CUDA-driver CMake issue was repaired. This independent build is not the supplied executable.')
s.append('| Split | Existing depth | Test | Median tok/s |\n|---|---:|---|---:|')
for x in read('official-bench-results.json',[]):
 s.append('| '+x['split_mode']+' | '+m(x['n_depth'])+' | '+('pp '+m(x['n_prompt']) if x['n_prompt'] else 'tg '+m(x['n_gen']))+' | '+m(statistics.median(x['samples_ts']))+' |')
s.append('Bench pp is an incremental prompt block after the stated depth. Server depth pp is a whole cold prompt. Bench has no HTTP/chat/sampler path. Per-repeat samples and the exact command are retained.')
s.append('## Allocation and failure observations\n| Configuration | Result |\n|---|---|')
for n,d in sorted(data.items()):
 if n.startswith(('alloc_','oom_')):s.append('| '+n+' | '+('failed [MEASURED]: `'+d['error']+'`' if d.get('error') else 'loaded [MEASURED]')+' |')
s.append(pathlib.Path('report-tail.md').read_text())
pathlib.Path('Artemis-T4-report.md').write_text('\n\n'.join(s))
with open('recommended-commands.sh','w') as f:
 f.write('#!/usr/bin/env bash\n# Run one measured profile at a time.\ncase "${1:-balanced}" in\n')
 for k,d in profiles.items():f.write('  '+k+') exec '+command(d)+' ;;\n')
 f.write('  *) echo "Choose speed, context, or balanced" >&2; exit 2 ;;\nesac\n')
pathlib.Path('evidence-README.md').write_text('Read Artemis-T4-report.md first. Raw hardware, metadata, run JSON, hashes and logs are [MEASURED] evidence. Calculation files are [CALCULATED], with assumed scratch headroom and nominal bandwidth [ESTIMATED]. Numeric script arguments and budgets are experiment settings. Identifiers are literal. Original logs are not rewritten. natural_* controls are excluded for missing BOS; chat_* supersede them. Allocation probes have no throughput trials. Full-depth continuations reuse a real growing prefix; cold prefill is measured once. Official bench differs from the supplied server. Models, executables and source/build trees are excluded.\n')
print(json.dumps({'rows':len(rows),'full_validated':ok,'report_bytes':pathlib.Path('Artemis-T4-report.md').stat().st_size}))
